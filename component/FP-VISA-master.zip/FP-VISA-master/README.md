FP-VISA
=======

VISA header conversion and VISA session component for Lazarus
